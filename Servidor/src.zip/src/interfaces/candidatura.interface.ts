export interface Candidatura {
  id?: number;
  propuesta: string;
  userid: number;
  eleccionid: number;
  createdat?: string;
  updatedat?: string;
}
