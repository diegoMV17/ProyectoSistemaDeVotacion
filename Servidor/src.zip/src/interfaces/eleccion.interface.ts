export interface Eleccion {
  id?: number;
  nombre: string;
  descripcion?: string;
  tipo_representacion?: string;
  fecha_inicio?: string;
  fecha_fin?: string;
  estado?: string;
  createdat?: string;
  updatedat?: string;
}